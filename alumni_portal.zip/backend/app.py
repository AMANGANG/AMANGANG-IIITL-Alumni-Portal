import numpy as np 
from flask import Flask, request, jsonify 
from flask_cors import CORS, cross_origin 
import pickle 
import json 

app = Flask(__name__)   
CORS(app, support_credentials=True) 

@app.route('/predict',methods=['POST']) 
@cross_origin(supports_credentials=True) 
def predict(): 
    data = request.get_json(force=True) 
    r = {"result" : 1 } 
    response = jsonify(r) 
    return response          

if __name__ == '_main_': 
    app.run(port=5000, debug=True)